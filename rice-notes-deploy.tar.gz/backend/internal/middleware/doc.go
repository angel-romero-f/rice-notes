// Package middleware provides reusable HTTP middleware for things like
// CORS handling, JWT Handling, Logging, etc.
package middleware
