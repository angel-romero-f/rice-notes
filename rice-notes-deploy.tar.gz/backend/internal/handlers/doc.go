// Package handlers defines the HTTP handlers for the Rice Notes API.
package handlers
