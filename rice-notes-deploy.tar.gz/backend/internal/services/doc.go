// Package services contains the core application logic and use case implementations
// for the Rice Notes platform.
package services
